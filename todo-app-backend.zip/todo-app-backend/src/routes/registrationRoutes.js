import express from "express";
import { upload } from "../middleWares/upload.js";
import {
    getAllRegistrations,
    getRegistration,
    addRegistration,
    editRegistration,
    removeRegistrationController,
} from "../controllers/registrationcontroller.js";

const router = express.Router();

// ✅ Routes
router.get("/", getAllRegistrations);
router.get("/:id", getRegistration);

// ✅ File Upload Route
router.post("/", upload.single("resume"), addRegistration);

// ✅ Update with optional new file
router.put("/:id", upload.single("resume"), editRegistration);

router.delete("/:id", removeRegistrationController);

export default router;
